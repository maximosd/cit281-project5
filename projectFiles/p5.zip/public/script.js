const btn = document.getElementById('open-btn');
const coinEl = document.getElementById('coin-count');
const invEl  = document.getElementById('inventory');

// Set your player name (could be dynamic)
const playerName = window.location.pathname.slice(1); // Change as needed

btn.addEventListener('click', openBox);

async function openBox() {
  try {
    const response = await fetch(`/api/${playerName}/open-box`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();
    if (response.ok) {
      coinEl.textContent = data.coins;
      // Show both emoji and tier, e.g. "🍞 (common)"
      invEl.textContent = data.inventory
        .map(item => `${item.emoji} (${item.tier})`)
        .join(', ');
    } else {
      alert(data.error || 'Error opening box');
    }
  } catch (err) {
    alert('Network error');
  }
}

// Optionally, fetch and display player info on page load
window.addEventListener('DOMContentLoaded', async () => {
  if (playerName) {
    alert(`Hello, ${playerName}!`);
  }
  const response = await fetch(`/api/${playerName}`);
  const data = await response.json();
  coinEl.textContent = data.coins;
  invEl.textContent = data.inventory
    .map(item => `${item.emoji} (${item.tier})`)
    .join(', ');
});
